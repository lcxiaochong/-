'use strict';
exports.main_handler = async (event, context, callback) => {
    require('./jd_speed.js')
}
